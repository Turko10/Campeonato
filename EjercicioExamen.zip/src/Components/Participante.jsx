function Participante(props) {
    return (
        <div className="accordion-item">
            <h2 className="accordion-header" id={'heading' + props.datos.id}>
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={'#collapse' + props.datos.id} aria-expanded="false" aria-controls={'collapse' + props.datos.id}>
                    {props.datos.name}
                </button>
            </h2>
            <div id={'collapse' + props.id} className="accordion-collapse collapse collapse" aria-labelledby={'heading' + props.id} data-bs-parent="#accordionLista">
                <div className="accordion-body">
                    <ul className='list-group list-group-flush'>
                        <li className='list-group-item'>Capital: {props.datos.capital}</li>
                        <li className='list-group-item'>Code: {props.datos.code}</li>
                        <li className='list-group-item'>Continent: {props.datos.continent}</li>
                    </ul>
                </div>
            </div>
        </div>
    )

}

export default Participante;


