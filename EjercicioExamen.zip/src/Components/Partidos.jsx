import MuestrarioResultados from "./MuestrarioResultados";
import { useState } from "react";

function Partidos(props) {
    
    return (
        <>
            <div className='row mt-2 mb-5'>
                <button type="button" class="btn btn-primary btn-lg btn-block">Generar Conflicto</button>
            </div>
            <div className='row mt-2 mb-5'>
                <button type="button" class="btn btn-primary btn-lg btn-block">Mostrar Resultados</button>
            </div>
           
        </>
    );
}

export default Partidos;


